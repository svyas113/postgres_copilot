# This file makes the 'db_copilot' directory a Python package.
